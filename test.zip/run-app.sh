#!/bin/bash

# Set environment variables
export FLASK_APP=app.py
export FLASK_DEBUG=true

venv_path=$(pwd)/venv

# Check for virtual environment
if [ ! -d "$venv_path" ]; then
  echo "Creating virtual environment..."
  python3 -m venv "$venv_path" &> /dev/null
  if [ $? -ne 0 ]; then
    echo "Error creating virtual environment!"
    exit 1
  fi

  echo "Installing Python dependencies..."
  sudo apt-get update &> /dev/null
  sudo apt-get install -y python3 python3-pip python3-venv &> /dev/null
  pip install -r requirements.txt &> /dev/null
  pip install Flask-Migrate &> /dev/null
fi

# Check if venv is already activated
if [ -n "$VIRTUAL_ENV" ]; then
  echo "Virtual environment already activated. Skipping activation."
  # Start Flask app server
  echo "Starting Flask app server..."
  flask run
else
  echo "Activating virtual environment..."
  source "$venv_path/bin/activate"
  if [ -n "$VIRTUAL_ENV" ]; then
    echo "Starting Flask app server..."
    flask run
  fi
fi


